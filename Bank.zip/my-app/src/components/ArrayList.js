import React from "react";

const ArrayList = props => <ul>{props.children}</ul>;
export default ArrayList;
